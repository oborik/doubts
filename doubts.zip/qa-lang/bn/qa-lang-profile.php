﻿<?php
	
/*
	Question2Answer (c) Gideon Greenspan

	http://www.question2answer.org/

	
	File: qa-include/qa-lang-profile.php
	Version: See define()s at top of qa-include/qa-base.php
	Description: Language phrases for user profile page


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
  Bangla (Bangladesh) Translation by Shubhra Prakash Paul <shuvro.paul@gmail.com>
*/

	return array(
		'answers_by_x' => "উত্তর দিয়েছেন ^",
		'delete_wall_post_popup' => "এই দেওয়াল পোস্ট টি মুছে ফেল ",
		'no_answers_by_x' => "^ কোন উত্তর দেন নি",
		'no_questions_by_x' => " ^ কোন প্রশ্ন করেন নি",
		'permit_edit_silent' => "নীরবে পোস্টগুলো সম্পাদনা করতে পারবেন ",
		'permit_post_wall' => "সদস্যবৃন্দের দেওয়ালে পোস্ট করা হচ্ছে ",
		'permit_view_voters_flaggers' => "কে ভোট দিয়েছে কিংবা পোস্টে ধ্বজা লাগিয়েছে তা দেখতে পাবেন ",
		'post_wall_blocked' => "এই সদস্য তার দেওয়ালে নতুন পোষ্ট করার অনুমতি বাতিল করেছেন ",
		'post_wall_button' => "দেওয়ালে পোস্ট যোগ কর",
		'post_wall_empty' => "এই দেওয়ালে পোস্ট করার জন্য কিছু তো একটা লিখুন ",
		'post_wall_limit' => "আপনি এই ঘন্টায় আর কোন দেওয়াল পোস্ট লিখতে পারবেন না ",
		'post_wall_must_be_approved' => "এই দেওয়ালে পোস্ট করতে চাইলে আপনার একাউন্টটি অবশ্যই অনুমোদিত হতে হবে।",
		'post_wall_must_confirm' => "এই দেওয়ালে পোস্ট করার জন্য দয়া করে আপনার ^5 ই-মেইল ঠিকানাটি যাচাই করুন ^6 ।",
		'post_wall_must_login' => "এই দেওয়ালে পোস্ট করতে চাইলে দয়া করে  ^1 প্রবেশ করুন ^2  কিংবা  ^3 নিবন্ধিত হউন ^4 ।",
		'questions_by_x' => " ^ এর করা প্রশ্নগুচ্ছ",
		'wall_for_x' => " ^ এর দেওয়াল",
		'wall_view_more' => "আরও দেওয়াল পোস্ট দেখাও...",
		'1_chosen_as_best' => ' (1 সর্বোত্তম হিসাবে নির্বাচিত )',
		'1_down_vote' => '1 টি অসম্মত ভোট',
		'1_up_vote' => '1 টি সম্মত ভোট',
		'1_with_best_chosen' => ' (1 নির্বাচিত সর্বোত্তম উত্তর সম্বলিত )',
		'activity_by_x' => ' "^" র কার্যক্রম ',
		'answers' => 'উত্তরঃ',
		'bonus_points' => 'বোনাস পয়েন্টঃ',
		'comments' => 'মন্তব্যসমূহঃ',
		'extra_privileges' => 'অতিরিক্ত সুবিধাদিঃ',
		'gave_out' => 'দান করেছেন:',
		'my_account_title' => 'আমার একাউন্টের বিশদ বিবরণ',
		'no_posts_by_x' => '^ কোন পোস্ট করেন নি',
		'permit_anon_view_ips' => 'অজ্ঞাতকুলশীল পোস্টের আইপি দর্শন করতে পারবেন ',
		'permit_close_q' => 'যে কোন প্রশ্ন বন্ধ করতে পারবেন ',
		'permit_delete_hidden' => 'লুক্কায়িত পোস্টগুলো মুছে ফেলতে পারবেন ',
		'permit_edit_a' => 'যে কোন উত্তর সম্পাদনা  করতে পারবেন ',
		'permit_edit_c' => 'যে কোন মন্তব্য সম্পাদনা করতে পারবেন ',
		'permit_edit_q' => 'যে কোন প্রশ্ন সম্পাদনা করতে পারবেন  ',
		'permit_flag' => 'পোষ্টে ধ্বজা প্রয়োগ করতে পারবেন ',
		'permit_hide_show' => 'যে কোন পোস্ট প্রদর্শন করানো কিংবা লুকিয়ে রাখতে পারবেন ',
		'permit_moderate' => 'পোস্ট অনুমোদন কিংবা অননুমোদন দান করতে পারবেন ',
		'permit_post_a' => 'প্রশ্নের উত্তর প্রদান করতে পারবেন ' ,
		'permit_post_c' => 'মন্তব্য যোগ করতে পারবেন ',
		'permit_post_q' => 'প্রশ্ন জিজ্ঞাসা করতে পারবেন  ',
		'permit_recat' => 'যে কোন প্রশ্নকে পূনঃরায় বিভাগ বন্টন করতে পারবেন ',
		'permit_retag' => 'যে কোন প্রশ্নে তকমা পূনঃপ্রয়োগ করতে পারবেন ',
		'permit_select_a' => 'যে কোন প্রশ্নের  জন্য উত্তর নির্বাচন করতে পারবেন ',
		'permit_view_q_page' => 'প্রশ্ন পৃষ্ঠাসমূহ দর্শন করতে পারবেন ',
		'permit_vote_a' => 'উত্তরে ভোট প্রদান করতে পারবেন ',
		'permit_vote_down' => 'অসম্মত ভোটপ্রদান করতে পারবেন ',
		'permit_vote_q' => 'প্রশ্নে ভোট দিতে পারবেন',
		'questions' => 'প্রশ্নঃ',
		'ranked_x' => ' (র‌্যাংক  #  ^ )',
		'received' => 'প্রাপ্তঃ',
		'recent_activity_by_x' => ' "^" র সাম্প্রতিক কার্যকলাপ',
		'score' => 'স্কোরঃ ',
		'send_private_message' => ' - ^1 একান্ত বার্তা পাঠাও ^2',
		'set_bonus_button' => 'বোনাস পরিবর্ধন কর',
		'title' => 'শিরোনামঃ',
		'user_x' => 'সদস্যঃ   ^',
		'voted_on' => 'ভোট দিয়েছেনঃ ',
		'x_chosen_as_best' => ' (^ সর্বোত্তম হিসাবে নির্বাচন করেছেন)',
		'x_down_votes' => '^ অসম্মত ভোট',
		'x_up_votes' => '^ সম্মত ভোট',
		'x_with_best_chosen' => ' (^  নির্বাচিত সর্বোত্তম উত্তর সম্বলিত)',
	);
	

/*
	Omit PHP closing tag to help avoid accidental output
*/