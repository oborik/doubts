﻿<?php
	
/*
	Question2Answer (c) Gideon Greenspan

	http://www.question2answer.org/

	
	File: qa-include/qa-lang-misc.php
	Version: See define()s at top of qa-include/qa-base.php
	Description: Miscellaneous language phrases


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
  Bangla (Bangladesh) Translation by Shubhra Prakash Paul <shuvro.paul@gmail.com>
*/

	return array(
		'captcha_approve_fix' => "আপনার একাউন্টটি অনুমোদিত হওয়ার পরেই কেবল এই যাচাইকরণটি বন্ধ হবে ।",
		'form_security_again' => "নিশ্চিত করতে পূনঃরায় ক্লিক করুন ",
		'form_security_reload' => "দয়া করে এই পৃষ্ঠাটি পূনঃরায় লোড করুন এবং পূনঃরায় চেষ্টা করে দেখুন ",
		'nav_user_activity' => "সাম্প্রতিক কর্মকান্ড",
		'nav_user_as' => "সকল উত্তর",
		'nav_user_qs' => "সকল প্রশ্ন",
		'nav_user_wall' => "দেওয়াল",
		'your_a_commented' => "আপনার উত্তরে  মন্তব্য করা হয়েছে ",
		'your_a_edited' => "আপনার উত্তর সম্পাদিত হয়েছে ",
		'your_a_hidden' => "আপনার উত্তরটি লুকিয়ে রাখা হয়েছে",
		'your_a_questioned' => "আপনার উত্তরটতে জিজ্ঞাসা করা হয়েছে ",
		'your_a_reshown' => "আপনার উত্তরটি পূনঃপ্রদর্শিত হয়েছে",
		'your_a_selected' => "আপনার উত্তরটি নির্বাচিত হয়েছে",
		'your_c_edited' => "আপনার মন্তব্যটি সম্পাদিত হয়েছে",
		'your_c_followed' => "আপনার মন্তব্যটি অনুসৃত হচ্ছে ",
		'your_c_hidden' => "আপনার মন্তব্যটি  লুক্কায়িত",
		'your_c_moved' => "আপনার মন্তব্যটি  স্থানান্তরিত",
		'your_c_reshown' => "আপনার মন্তব্যটি  পূনঃপ্রদর্শিত",
		'your_q_answered' => "আপনার প্রশ্নের উত্তর দেওয়া হয়েছে",
		'your_q_closed' => "আপনার প্রশ্ন বন্ধ",
		'your_q_commented' => "আপনার প্রশ্নে মন্তব্য করা হয়েছে",
		'your_q_edited' => "আপনার প্রশ্ন সম্পাদনা করা হয়েছে",
		'your_q_hidden' => "আপনার প্রশ্ন লুক্কায়িত",
		'your_q_recategorized' => "আপনার প্রশ্ন পূনঃরায় ক্যাটেগরিতে ভুক্ত করা হয়েছে ",
		'your_q_reopened' => "আপনার প্রশ্ন পূনঃরায় খোলা হয়েছে",
		'your_q_reshown' => "আপনার প্রশ্ন পূনঃপ্রদর্শিত হয়েছে",
		'your_q_retagged' => "আপনার প্রশ্নটি পূনরায় তকমাযুক্ত করা হয়েছে ",
		'block_ip_button' => 'IP ঠিকানা বাধা দাও ',
		'browse_categories' => 'বিভাগসমূহ  ব্রাউজ কর ',
		'captcha_confirm_fix' => 'ভবিষ্যতে এই যাচাইকরণ  অগ্রাহ্য করতে, দয়া করে আপনার  ^5 ই-মেইল ঠিকানা যাচাই ^6 করুন ।',
		'captcha_error' => 'দয়া করে অনাযাচিত যাচাইকরণ সুসম্পন্ন করুন ',
		'captcha_label' => ' অনাযাচিত যাচাইকরণ:',
		'captcha_login_fix' => ' ভবিষ্যতে এই যাচাইকরণ  অগ্রাহ্য করতে, দয়া করে  ^1 প্রবেশ ^2  অথবা  ^3 নিবন্ধন^4 করুন । ',
		'feed_a_edited_prefix' => 'সম্পাদিত উত্তর : ',
		'feed_a_prefix' => 'উত্তরিত: ',
		'feed_a_reshown_prefix' => 'পূনঃপ্রদর্শিত উত্তর : ',
		'feed_a_selected_prefix' => 'নির্বাচিত  উত্তর : ',
		'feed_c_edited_prefix' => 'সম্পাদিত মন্তব্য : ',
		'feed_c_moved_prefix' => 'স্থানান্তরিত মন্তব্য : ',
		'feed_c_prefix' => 'মন্তব্যকৃত: ',
		'feed_c_reshown_prefix' => 'পূনঃপ্রদর্শিত মন্তব্য: ',
		'feed_closed_prefix' => 'বন্ধ: ',
		'feed_edited_prefix' => 'সম্পাদিত: ',
		'feed_hidden_prefix' => 'লুক্কায়িত: ',
		'feed_not_found' => 'ফিড খুঁজে পাওয়া গেল না ',
		'feed_recategorized_prefix' => 'বিভাগ পূনর্বিন্যস্ত : ',
		'feed_reopened_prefix' => 'পূনঃরায় খোলা: ',
		'feed_reshown_prefix' => 'পূনঃপ্রদর্শিত: ',
		'feed_retagged_prefix' => 'পূনঃতকমাযুক্ত: ',
		'feedback_email' => 'আপনার ই-মেইল: (ঐচ্ছিক)',
		'feedback_empty' => 'কোন মন্তব্য করতে কিংবা পরামর্শ দিতে দয়া করে এই ক্ষেত্রটি ব্যবহার করুন ',
		'feedback_message' => '^ এর জন্য আপনার পরামর্শ কিংবা মন্তব্য :',
		'feedback_name' => 'আপনার নাম : (ঐচ্ছিক)',
		'feedback_sent' => 'আপনার নিম্নোক্ত  বার্তাটি পাঠানো হয়েছে  -  ধন্যবাদ ।',
		'feedback_title' => 'ফিডব্যাক পাঠাও ',
		'hide_all_ip_button' => 'এই IP থেকে প্রাপ্ত সমস্ত পোস্ট লুকিয়ে রাখ ',
		'host_name' => 'হোস্টের নাম :',
		'matches_blocked_ips' => ' সামঞ্জস্যপূর্ণ বাধাগ্রস্থ IP ঠিকানাসমূহ : ',
		'message_empty' => 'এই  সদস্যকে  পাঠানোর জন্য বার্তা লিখুন ',
		'message_explanation' => 'এটি  ^ থেকে  অবহিতকরণ হিসাবে পাঠানো হবে। বার্তায় ই-মেইল ঠিকানা সংযুক্ত না করলে, আপনার ই-মেইল ঠিকানাটি প্রকাশ করা হবে না ।',
		'message_for_x' => '^ এর জন্য আপনার বার্তা :',
		'message_limit' => 'অত্যধিক ব্যক্তিগত বার্তা পাঠানো হয়েছে  - দয়া করে এক ঘন্টা পর পূনঃরায় চেষ্টা করুন ',
		'message_must_login' => 'ব্যক্তিগত বার্তা পাঠাতে দয়া করে  ^1 প্রবেশ ^2   কিংবা  ^3 নিবন্ধন ^4  করুন ।',
		'message_received_x_ago' => '^ পূর্বে প্রাপ্ত:',
		'message_recent_history' => '^ এর সঙ্গে সাম্প্রতিক কথোপকথন ',
		'message_sent_x_ago' => '^  পূর্বে পাঠানো:',
		'message_sent' => ' আপনার পাঠানো ব্যক্তিগত বার্তা নিম্নরূপ ',
		'my_favorites_title' => 'আমার প্রিয়',
		'nav_all_my_updates' => 'আমার পরিবর্ধনসমগ্র',
		'nav_my_content' => 'আমার বিষয়বস্তু',
		'nav_my_details' => 'আমার বিশদ বিবরণ',
		'nav_my_favorites' => 'আমার প্রিয়',
		'no_activity_from_x' => ' ^ থেকে কোন কর্মকান্ড নেই ',
		'no_favorite_categories' => 'কোন প্রিয় বিভাগ নেই ',
		'no_favorite_qs' => 'কোন প্রিয় প্রশ্ন নেই ',
		'no_favorite_tags' => 'কোন প্রিয়  তকমা নেই ',
		'no_favorite_users' => 'কোন প্রিয় সদস্য নেই ',
		'no_recent_updates' => 'সাম্প্রতিক কোন পরিবর্ধন নেই ',
		'no_updates_content' => 'আমার বিষয়োপকরণের জন্য সাম্প্রতিক কোন পরিবর্ধন নেই ',
		'no_updates_favorites' => 'আমার প্রিয়সমূহের জন্য কোন পরিবর্ধন নেই   ',
		'private_message_title' => 'ব্যক্তিগত বার্তা পাঠানো ',
		'recent_activity_from_x' => ' ^ এর সাম্প্রতিক কর্মকান্ড',
		'recent_updates_content' => 'আমার বিষয়োপকরণের জন্য সাম্প্রতিক পরিবর্ধনসমূহ ',
		'recent_updates_favorites' => 'আমার প্রিয়সমূহের জন্য সাম্প্রতিক পরিবর্ধনসমূহ',
		'recent_updates_title' => 'আমার জন্য সাম্প্রতিক পরিবর্ধনসূহ ',
		'site_in_maintenance' => 'এই সাইট টি  মেরামতের জন্য বর্তমানে উপলভ্য নয়  -  দয়া করে শীঘ্রই ফিরে আসুন ।',
		'suggest_favorites_add' => 'আপনার প্রিয়তে প্রশ্ন যোগ করতে কিংবা অন্য কোন বিষয়োপকরণ যোগ করতে , এই  পৃষ্ঠার শীর্ষদেশে  ^ এ ক্লিক করুন ।',
		'suggest_update_favorites' => 'আরও পরিবর্ধন পেতে, ^1 আপনার প্রিয় ^2 তে বিষয়োপকরণ যোগ করুন  ',
		'unblock_ip_button' => 'IP ঠিকানার বাধা অপসারণ কর ',
	);
	

/*
	Omit PHP closing tag to help avoid accidental output
*/