﻿<?php
	
/*
	Question2Answer (c) Gideon Greenspan

	http://www.question2answer.org/

	
	File: qa-include/qa-lang-users.php
	Version: See define()s at top of qa-include/qa-base.php
	Description: Language phrases for user management


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
  Bangla (Bangladesh) Translation by Shubhra Prakash Paul <shuvro.paul@gmail.com>
*/

	return array(
		'approve_required' => "একাউন্টটি অনুমোদিত হওয়া পর্যন্ত কিংবা  ^1 আরও তথ্য যোগ করার জন্য ^2 দয়া করে অপেক্ষা করুন ",
		'approve_title' => "মুলতুবি রাখা সদস্য অনুমোদন",
		'approve_user_button' => "সদস্য অনুমোদন দাও",
		'approved_user' => "অনুমোদিত সদস্য",
		'category_level_add' => " - ^1ক্যাটেগরি-ভিত্তিক সুবিধা যোগ কর ^2",
		'category_level_in' => "নিম্নোক্ত ক্যাটেগরির জন্যঃ ",
		'category_level_label' => "পরিবর্ধন করঃ",
		'category_level_none' => "কোন পরিবর্ধন নেই",
		'level_for_category' => "^1 এর জন্য ^2",
		'level_in_general' => "সাধারণ",
		'only_shown_editors' => "(শুধুমাত্র সম্পাদক কিংবা তদুর্দ্ধ পদমর্যাদার লোকেদের নিকট প্রদর্শিত )",
		'only_shown_experts' => "(শুধুমাত্র বিশেষজ্ঞ কিংবা তদুর্দ্ধ পদমর্যাদার লোকেদের নিকট প্রদর্শিত )",
		'wall_posts' => "দেওয়াল পোস্টগুলোঃ",
		'wall_posts_explanation' => "আপনার দেওয়ালে পোস্ট করার জন্য সদস্যদের অনুমতি দিন (আপনাকেও ই-মেইলে জানানো হবে )",
		'registered_label' => "নিবন্ধিতঃ",
		'remember' => "মনে রাখ",
		'about' => 'আমার সম্পর্কে আরো কিছু',
		'add_user_x_favorites' => ' আমার প্রিয় তে সদস্য "^" কে যোগ কর ',
		'avatar_default' => 'পূর্বনির্ধারিত',
		'avatar_gravatar' => ' আমার ^1 গ্রাভতার ^2 ব্যবহার কর',
		'avatar_label' => 'আমার অবতারঃ ',
		'avatar_none' => 'কোনটিই নয়',
		'block_user_button' => 'সদস্যকে বাধা দাও',
		'blocked_users' => 'বাধাপ্রাপ্ত সদস্যবৃন্দ',
		'change_email_link' => ' - ^1 ই-মেইল পরিবর্তন ^2',
		'change_password' => 'কূটশব্দ পরিবর্তন কর ',
		'confirm_complete' => 'ধন্যবাদ - আপনার ই-মেইল ঠিকানাটি যাচাই করা হয়েছে',
		'confirm_emailed' => ' আপনার ই-মেইলে একটি যাচাইকরণ লিংক পাঠানো  হয়েছে । আপনার ই-মেইল ঠিকানা যাচাই করতে দয়া করে লিংকটি তে ক্লিক করুন ।',
		'confirm_required' => 'আপনার নিবন্ধন প্রক্রিয়া সুসম্পন্ন করতে , আপনার ই-মেইলে পাঠানো যাচাইকরণ লিংকটিতে ক্লিক করুন  অথবা  ^1 নতুন একটি যাচাইকরণ লিংক^2 এর জন্য অনুরোধ করুন ।',
		'confirm_title' => 'ই-মেইল ঠিকানা যাচাই করণ ',
		'confirm_wrong_log_in' => 'কোড টি সঠিক নয়   -  নতুন লিংকটি পাঠাতে  ^1প্রবেশ^2  করুন ।',
		'confirm_wrong_resend' => 'কোড টি সঠিক নয় -  নতুন একটি লিংক পাঠাতে চাইলে  নিচে ক্লিক করুন ',
		'delete_user_button' => 'সদস্য মুছে ফেল',
		'edit_user_button' => 'সদস্য সম্পাদনা কর',
		'email_confirmed' => ' ই-মেইল যাচাইকৃত',
		'email_exists' => 'ই-মেইলটি একটি একাউন্টের সাথে যুক্ত ',
		'email_handle_label' => 'ই-মেইল অথবা সদস্যনামঃ',
		'email_invalid' => 'ই-মেইলটি সঠিক নয় - দয়া করে সংশোধন করুন',
		'email_label' => 'আমার ই-মেইলঃ ',
		'email_not_confirmed' => 'এখনও যাচাইকৃত নয়',
		'email_please_confirm' => 'দয়া করে ই-মেইল ঠিকানাটি ^5 যাচাই করুন^6 ।',
		'email_required' => 'ই-মেইল ঠিকানা আবশ্যক -  জনসমক্ষে প্রদর্শিত হবে না ',
		'forgot_link' => 'আমি আমার কূটশব্দটি ভুলে গিয়েছি',
		'full_name' => 'আমার পূর্ণ নাম ',
		'handle_empty' => 'সদস্যনামটি ফাঁকা রাখা চলবে না ',
		'handle_exists' => 'সদস্যনামটি ইতোমধ্যে কেউ গ্রহণ করেছেন  - দয়া করে অন্য আর একটি চেষ্টা করুন ',
		'handle_has_bad' => 'সদস্যনামে থাকা চলবে না: ^',
		'handle_label' => 'আমার সদস্যনাম ',
		'hide_all_user_button' => ' এই সদস্যের সমস্ত পোস্ট লুকিয়ে রাখ ',
		'last_login_label' => 'সর্বশেষ প্রবেশ',
		'last_write_label' => 'সর্বশেষ লিখন পদক্ষেপ :',
		'level_admin' => 'প্রশাসক',
		'level_editor' => 'সম্পাদক',
		'level_expert' => 'বিশেষজ্ঞ',
		'level_moderator' => 'সমন্বয়ক',
		'level_super' => 'মহা সমন্বয়ক',
		'location' => ' আমার অবস্থান যেখানে  ',
		'log_in_to_access' => 'আপনি এখন আপনার একাউন্টে ^1 প্রবেশ ^2  করতে পারবেন ।',
		'login_button' => 'প্রবেশ',
		'login_limit' => 'অত্যধিক সংখ্যক প্রবেশের চেষ্টা -  ধয়া করে এক ঘন্টা পর আবার চেষ্টা করে দেখুন',
		'login_title' => 'প্রবেশ',
		'mass_mailings_explanation' => 'সমস্ত সদস্যবৃন্দকে পাঠানো ই-মেইলের গ্রাহক হতে চাই ',
		'mass_mailings' => 'গণ বার্তাঃ',
		'member_for' => ' আমি সদস্য হয়েছি ',
		'member_type' => 'সদস্যের ধরণ ',
		'new_password_1' => 'নতুন কূটশব্দঃ',
		'new_password_2' => 'নতুন কূটশব্দটি পূনর্বারঃ ',
		'no_blocked_users' => 'বাধাপ্রাপ্ত কোন সদস্য খুঁজে পাওয়া গেল না ',
		'no_permission' => ' আপনি এই পদক্ষেপ নেওয়ার জন্য  অনুমতি প্রাপ্ত নন ',
		'old_password' => 'পুরাতন কূটশব্দঃ',
		'only_shown_admins' => '(শুধুমাত্র প্রশাসকবৃন্দের নিকট দৃশ্যমান)',
		'only_shown_moderators' => '(শুধুমাত্র সমন্বয়কবৃন্দের নিকট দৃশ্যমান))',
		'password_changed' => 'কূটশব্দ পরিবর্তন করা হয়েছে',
		'password_label' => 'কূটশব্দঃ',
		'password_min' => 'কূটশব্দটি কমপক্ষে  ^ বর্ণের হতে হবে ',
		'password_mismatch' => 'নতুন কূটশব্দদ্বয় পরষ্পরের সাথে মেলে না ',
		'password_none' => 'কোনটিই নয়। সরাসরি প্রবেশ করতে  হলে নিচে একটি কূটশব্দ নির্ধারণ করুন।',
		'password_sent' => 'আপনার নতুন কূটশব্দটি ই-মেইলে পাঠানো হয়েছে ',
		'password_to_set' => 'আপনার একাউন্ট পাতায় নির্ধারণ করুন ',
		'password_wrong' => 'কূটশব্দ সঠিক  নয় ',
		'private_messages_explanation' => 'সদস্যবৃন্দ আমাকে ই-মেইল করতে পারবে  ( আমার ই-মেইল ঠিকানা না জেনেই )',
		'private_messages' => 'একান্ত বার্তাঃ',
		'profile_saved' => 'বৃত্তান্ত সংরক্ষণ করা হয়েছে',
		'register_button' => 'নিবন্ধন কর',
		'register_limit' => 'অত্যধিক নিবন্ধনের প্রচেষ্টা-  দয়া করে এক ঘন্টা পর পূনঃরায় চেষ্টা করুন ',
		'register_suspended' => 'নতুন সদস্য নিবন্ধন এই মুহুর্তে নিষ্ক্রিয় আছে । খুব শীঘ্রই আবার চেষ্টা করে দেখতে পারেন ।',
		'register_title' => 'নতুন সদস্য হিসাবে নিবন্ধন করুন',
		'registered_user' => 'নিবন্ধিত সদস্য',
		'remember_label' => 'এই কম্পিউটারে আমাকে মনে রাখ',
		'remove_avatar' => 'অবতার সরিয়ে ফেলঃ',
		'reset_code_another' => 'আরেকটি কোড পাঠাও',
		'reset_code_emailed' => 'পূনঃনির্ধারণ কোডটি আপনার কাছে ই-মেইলে পাঠানো হয়েছে',
		'reset_code_label' => 'কোডঃ',
		'reset_code_wrong' => 'কোডটি সঠিক নয়',
		'reset_title' => 'ভুলে যাওয়া কূটশব্দ পূনঃনির্ধারণ কর',
		'save_profile' => 'বৃত্তান্ত সংরক্ষণ কর',
		'save_user' => 'সদস্য সংরক্ষণ কর',
		'send_confirm_button' => 'যাচাইকরণ লিংকটি পাঠাও',
		'send_password_button' => 'নতুন কূটশব্দ পাঠাও',
		'send_reset_button' => 'কূটশব্দ পূনঃনির্ধারণের জন্য ই-মেইল পাঠাও ',
		'send_reset_note' => 'পরবর্তী নির্দেশনা সম্বলিত একটি বার্তা আপনার ই-মেইল ঠিকানায় পাঠানো হয়েছে ।',
		'special_users' => 'বিশেষ সদস্যবৃন্দ',
		'unblock_user_button' => 'সদস্যের উপর নিষেধাজ্ঞা তুলে নাও',
		'unsubscribe_complete' => ' ^0 এর নিকট থেকে পাঠানো গণ-বার্তা প্রাপ্তি থেকে আপনি আপনার গ্রাহকত্ব প্রত্যাহার করেছেন । আপনি  যে কোন সময়  ^1 একাউন্ট^2  পাতা থেকে পূনঃরায় গ্রাহক হওয়ার জন্য আবেদন করতে পারেন ।', 
		'unsubscribe_title' => 'গ্রাহকত্ব বাতিল ',
		'unsubscribe_wrong_log_in' => 'কোডটি সঠিক নয় -  গ্রাহকত্ব বাতিল করতে দয়া করে  ^1প্রবেশ ^2  করুন',
		'unsubscribe' => 'গ্রাহকত্ব বাতিলঃ ',
		'user_blocked' => '(বাধাগ্রস্থ)',
		'user_not_found' => 'সদস্য খুঁজে পাওয়া গেল না',
		'website' => ' আমার ওয়েবসাইট ',
		'x_ago_from_y' => '^1 পূর্বে ^2 ',
	);
	

/*
	Omit PHP closing tag to help avoid accidental output
*/