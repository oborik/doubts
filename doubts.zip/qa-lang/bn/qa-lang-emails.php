﻿<?php
	
/*
	Question2Answer (c) Gideon Greenspan

	http://www.question2answer.org/

	
	File: qa-include/qa-lang-emails.php
	Version: See define()s at top of qa-include/qa-base.php
	Description: Language phrases for email notifications


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
  Bangla (Bangladesh) Translation by Shubhra Prakash Paul <shuvro.paul@gmail.com>
*/

	return array(
		'remoderate_body' => "^p_handle কর্তৃক সম্পাদিত একটি পোস্ট আপনার অনুমোদনের অপেক্ষায় আছেঃ \n\n^open^p_context^close\n\nসম্পাদিত পোস্ট টি অনুমোদন দিতে কিংবা লুকিয়ে রাখতে নিচে ক্লিক করুনঃ \n\n^url\n\n\nঅপেক্ষমান সকল পোস্ট রিভিউ করতে নিচে ক্লিক করুনঃ \n\n^a_url\n\n\nধন্যবাদান্তে,\n\n^site_title",
		'remoderate_subject' => "^site_title মডারেসন",
		'u_registered_body' => "নতুন একজন ব্যবহারকারি ^u_handle নামে নিবন্ধন করেছেন । \n\nসদস্যের বৃত্তান্ত দেখতে নিচে ক্লিক করুন :\n\n^url\n\nধন্যবাদান্তে, \n\n^site_title",
		'u_to_approve_body' => "নতুন একজন ব্যবহারকারি ^u_handle নামে নিবন্ধিত হয়েছেন । \n\এই সদস্যকে অনুমোদন দিতে নিচে ক্লিক করুনঃ \n\n^url\n\nঅপেক্ষমান সকল সদস্যকে অনুমোদন দিতে নিচে ক্লিক করুন:\n\n^a_url\n\nধন্যবাদান্তে,\n\n^site_title",
		'u_registered_subject' => "^site_title এ নতুন সদস্য নিবন্ধিত হয়েছেন ।",
		'u_approved_body' => "আপনি এখান থেকে আপনার নতুন সদস্যের বৃত্তান্তটি দেখতে পাবেন :\n\n^url\n\nThank you,\n\n^site_title",
		'u_approved_subject' => "আপনার ^site_title সদস্য অনুমোদিত হয়েছে।",
		'wall_post_subject' => "আপনার ^site_title দেওয়ালে পোস্ট করুন",
		'wall_post_body' => "^f_handle আপনার দেওয়ালে পোস্ট করেছেন এখানে ^site_title:\n\n^open^post^close\n\nআপনি এখানে এটার প্রতিক্রিয়া জানাতে পারেনঃ \n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'a_commented_body' => " ^site_title এ আপনার দেওয়া উত্তরে মন্তব্য করেছেন  ^c_handle:\n\n^open^c_content^close\n\nআপনার উত্তরটি ছিল:\n\n^open^c_context^close\n\nআপনি আপনার নিজের মন্তব্য করে প্রতিক্রিয়া জ্ঞাপন করতে পারেন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'a_commented_subject' => 'আপনার ^site_title এ প্রদত্ত উত্তরে নতুন মন্তব্য করা হয়েছে ',

		'a_followed_body' => "^site_title এ আপনার দেওয়া উত্তরের সাথে সম্পর্কিত একটি প্রশ্ন করেছেন  ^q_handle:\n\n^open^q_title^close\n\nআপনার উত্তরটি ছিল:\n\n^open^a_content^close\n\nনতুন প্রশ্নের উত্তর দিতে নীচের লিংকে ক্লিক করুন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'a_followed_subject' => '^site_title এ আপনার প্রদত্ত উত্তরের সাথে সম্পর্কিত একটি প্রশ্ন আছে ',

		'a_selected_body' => "অভিনন্দন ! ^site_title এ আপনার প্রদত্ত উত্তরটিকে ^s_handle সর্বোত্তম উত্তর হিসাবে নির্বাচন করেছেন :\n\n^open^a_content^close\n\nপ্রশ্নটি ছিল:\n\n^open^q_title^close\n\nআপনার উত্তরটি দেখতে নিচে ক্লিক করুন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'a_selected_subject' => '^site_title এ আপনার উত্তরটি নির্বিচত হয়েছে !',

		'c_commented_body' => "^site_title: এ আপনার প্রদত্ত মন্তব্যে ^c_handle নতুন একটি মন্তব্য করেছেন \n\n^open^c_content^close\n\nআলোচনাটি নিম্নরূপ :\n\n^open^c_context^close\n\nআপনি আরেকটি মন্তব্য করে প্রতিক্রিয়া জ্ঞাপন করতে পারেন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'c_commented_subject' => '^site_title এ আপনার মন্তব্য যোগ করা হয়েছে ',

		'confirm_body' => "^site_title এ আপনার ই-মেইল ঠিকানাটি যাচাই করার জন্য নিম্নোক্ত লিংকে ক্লিক করুন ।\n\n^url\n\nধন্যবাদান্তে,\n^site_title",
		'confirm_subject' => '^site_title - ই-মেইল যাচাইকরণ',

		'feedback_body' => "মন্তব্যসমূহ:\n^message\n\nনাম:\n^name\n\nই-মেইল:\n^email\n\nপূর্ববর্তী পাতা:\n^previous\n\nসদস্য:\n^url\n\nIP ঠিকানা:\n^ip\n\nব্রাউজার:\n^browser",
		'feedback_subject' => '^ ফিডব্যাক',

		'flagged_body' => "^p_handle এর করা একটি পোস্টে ধ্বজা প্রযুক্ত হয়েছে ^flags:\n\n^open^p_context^close\n\nপোস্ট টি দেখতে নীচে ক্লিক করুন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'flagged_subject' => '^site_title এ ধ্বজাযুক্ত পোস্ট আছে ',

		'moderate_body' => "^p_handle এর করা একটি পোস্টে আপনার অনুমোদন প্রয়োজন :\n\n^open^p_context^close\n\nপোস্টটি অনুমোদন দিতে কিংবা প্রত্যাখান করতে নীচে ক্লিক করুন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'moderate_subject' => '^site_title সমন্বয়করণ',

		'new_password_body' => "নিচে  ^site_title এর জন্য আপনার নতুন কূটশব্দ টি  প্রদর্শিত হলো ।\n\nকূটশব্দ: ^password\n\nপ্রবেশ করার অবব্যহিত পরেই এই কূটশব্দটি পরিবর্তন করার জন্য  অনুরোধ করছি ।\n\nধন্যবাদান্তে,\n^site_title\n^url",
		'new_password_subject' => '^site_title - আপনার নতুন কূটশব্দ ',

		'private_message_body' => "^site_title এ  ^f_handle আপনাকে একটি ব্যক্তিগত বার্তা পাঠিয়েছেন :\n\n^open^message^close\n\n^more ধন্যবাদান্তে,\n\n^site_title\n\n\nব্যক্তিগত বার্তা আদানপ্রদান বন্ধ করতে, আপনার একাউন্ট পাতায় গিয়ে নির্ধারণ করুন:\n^a_url",
		'private_message_info' => "^f_handle সম্পর্কে আরও বিশদ তথ্য :\n\n^url\n\n",
		'private_message_reply' => "^f_handle কে উত্তর দিতে নীচের ক্লিক করে ব্যক্তিগত বার্তা পাঠান:\n\n^url\n\n",
		'private_message_subject' => '^site_title এ   ^f_handle প্রেরিত বার্তা ',

		'q_answered_body' => "^site_title এ আপনার প্রশ্নের উত্তর দিয়েছেন ^a_handle:\n\n^open^a_content^close\n\nআপনার প্রশ্নটি ছিল:\n\n^open^q_title^close\n\nআপনি এই উত্তরটি পছন্দ করলে একে সর্বোত্তম উত্তর হিসাবে নির্বাচন করতে পারেন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'q_answered_subject' => 'আপনার ^site_title প্রশ্নের জবাব মিলেছে ',

		'q_commented_body' => "^site_title এ আপনার প্রশ্নে নতুন মন্তব্য করেছেন  ^c_handle:\n\n^open^c_content^close\n\nYour question was:\n\n^open^c_context^close\n\nআপনি আপনার নিজের মন্তব্য প্রদান করে প্রতিক্রিয়া জ্ঞাপন করতে পারেন:\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'q_commented_subject' => '^site_title এ আপনার প্রশ্নের নতুন মন্তব্য আছে ',

		'q_posted_body' => "নতুন একটি প্রশ্ন করছেন ^q_handle:\n\n^open^q_title\n\n^q_content^close\n\nপ্রশ্নটি দেখতে নীচে ক্লিক করুন :\n\n^url\n\nধন্যবাদান্তে,\n\n^site_title",
		'q_posted_subject' => '^site_title এ নতুন প্রশ্ন আছে ',

		'reset_body' => "^site_title এ আপনার কূটশব্দটি পূনঃনির্ধারণ করতে নীচের লিংকে ক্লিক করুন । \n\n^url\n\nবিকল্প হিসাবে, প্রদত্তক্ষেত্রটিতে নিম্নোক্ত কোডটি প্রদান করুন । \n\nCode: ^code\n\nআপনি কূটশব্দ পূনঃনির্ধারণের অনুরোধ না করে থাকলে দয়া করে এই বার্তাটি অগ্রাহ্য করুন । \n\nধন্যবাদান্তে,\n^site_title",
		'reset_subject' => '^site_title - ভুলে যাওয়া কূটশব্দ পূনঃনির্ধারণ',

		'to_handle_prefix' => "প্রিয় ^,\n\n",

		'welcome_body' => "^site_title এ নিবন্ধনের জন্য আপনাকে অনেক ধন্যবাদ ।\n\n^custom^confirm আপনার প্রবেশের তথ্যাবলি নিম্নরূপ:\n\nই-মেইলঃ ^email\nকূটশব্দঃ ^password\n\n দয়া করে ভবিষ্যতের জন্য এই তথ্য নিরাপদে সংরক্ষণ করুন ।\n\nধন্যবাদান্তে, প্রশাসক \n\n^site_title\n^url",
		'welcome_confirm' => "আপনার ই-মেইলটি যাচাই করতে নিচের লিংকটিতে ক্লিক করুন । \n\n^url\n\n",
		'welcome_subject' => '^site_title এ সুস্বাগতম !',
	);
	

/*
	Omit PHP closing tag to help avoid accidental output
*/